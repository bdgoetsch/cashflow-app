# Cash Flow App — Vercel Deployment

## Deploy in 3 steps

1. Go to [vercel.com](https://vercel.com) and sign in with Google
2. Click **"Add New Project"** → **"Import"** → drag this folder in, or use the Vercel CLI
3. Click **Deploy** — Vercel auto-detects Vite and builds it

Your app will be live at a URL like `https://cashflow-app-xyz.vercel.app`

## Add to iPhone/iPad Home Screen

1. Open the Vercel URL in **Safari**
2. Tap the **Share** button (box with arrow at bottom of screen)
3. Tap **"Add to Home Screen"**
4. Name it **"Cash Flow"** → tap **Add**

## Local development

```bash
npm install
npm run dev
```
