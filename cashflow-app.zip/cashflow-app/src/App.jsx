import { useState, useEffect, useRef, useCallback, useMemo } from "react";

// ─── INITIAL FINANCIAL DATA ───────────────────────────────────────────────
const TODAY = new Date(2026, 1, 28); // Feb 28 2026

const DEFAULT_STATE = {
  chaseBalance: 73178.61,
  websterBalance: 6904.88,
  mmBalance: 869.00,  // Bernstein Money Market (as of Feb 28 2026)
  amexOutstanding: 21852.71,   // current unpaid statement balance (Amex stmt, due Mar 6)
  visaOutstanding: 1253.43,    // Feb 21 stmt (Jan21-Feb21 accrual ~$1,213/mo) due Mar 18
  amexAccruing: 500.90,        // charges since Feb 11 close: House Mgr $319, Peloton $47, Frontier $100, Subaru $14.90, Spotify $20
  visaAccruing: 283.03,        // charges since last Visa close (Feb 21, 7 days × ~$40/day)
  stipendScenario: 300,

  // Recurring bills - each: { id, name, amount, dayOfMonth, account, category, active, startDate, endDate, frequency, notes }
  recurringBills: [
    // INCOME - Ben ($300k base, biweekly THURSDAYS, MFJ, NY State only)
    // Anchored to actual: $6,570.06 regular / $6,346.20 commuter month
    // THREE phases as FICA and 401k max at different times:
    //   SS ($715.38/pay) maxes ~Jul 30 (paycheck #16, cumulative wages hit $176,100)
    //   401k ($1,038.46/pay) maxes ~Nov 5 (paycheck #23)
    // Phase 1: pays 1-15 (Jan 1 – Jul 17) — 401k + SS both deducted
    { id:"sal_a", name:"Ben Salary", amount:6570.06, dayOfWeek:4, account:"chase_in", category:"income", active:true, frequency:"biweekly",
      endDate: new Date(2026,6,28), notes:"Biweekly Thu · $6,570.06 net · verified actual · 401k + SS deducted" },
    // Phase 2: pays 16-22 (Jul 30 – Oct 22) — SS maxed (+$715.38), 401k still deducted
    { id:"sal_b", name:"Ben Salary (SS maxed)", amount:7285.44, dayOfWeek:4, account:"chase_in", category:"income", active:true, frequency:"biweekly",
      startDate: new Date(2026,6,30), endDate: new Date(2026,10,4), notes:"SS maxed ~Jul 30 · +$715/pay" },
    // Phase 3: pays 23-27 (Nov 5 – Dec 31) — SS + 401k both maxed
    { id:"sal_c", name:"Ben Salary (SS + 401k maxed)", amount:7846.21, dayOfWeek:4, account:"chase_in", category:"income", active:true, frequency:"biweekly",
      startDate: new Date(2026,10,5), endDate: new Date(2026,11,31), notes:"SS + 401k both maxed · +$1,276/pay vs phase 1" },
    // 2027: new cycle
    { id:"sal_2027", name:"Ben Salary", amount:6570.06, dayOfWeek:4, account:"chase_in", category:"income", active:true, frequency:"biweekly",
      startDate: new Date(2027,0,1), notes:"2027 – new 401k + SS cycle" },
    // COMMUTER BENEFIT: $350/mo deducted on last Thursday of each month ($280 pre-tax, $70 post-tax)
    // Net impact: -$223.86 on that paycheck (verified: $6,570.06 - $6,346.20 = $223.86)
    { id:"commuter", name:"Commuter Benefit Deduction", amount:223.86, dayOfWeek:4, account:"chase_out", category:"commuter", active:true, frequency:"monthly_last_weekday",
      notes:"Last Thu of month · $350 total ($280 pre-tax, $70 post-tax) · net impact -$223.86" },

    // INCOME - Jennie ($195k base, biweekly Fridays, verified from Aug 2025 pay stub)
    // Stub confirmed: post-max paycheck = $4,730 → scaled to $195k ≈ $4,883
    // Pre-max paycheck (401k $1,125/pay deducted) ≈ $4,017 ← matches ~$4,000 reported
    // Benefits deducted: Dep Care FSA $208.33, Medical FSA $8.33, Accident $15.99,
    //   Critical Illness $6.90, GTL $6.23 (medical/dental/vision paid by employer)
    // 401k: 15% = $1,125/pay → maxes $23,500 ~paycheck #21 (around Oct 9 2026)
    { id:"jsal_a", name:"Jennie Salary", amount:4017, dayOfWeek:5, account:"chase_in", category:"income", active:true, frequency:"biweekly",
      endDate: new Date(2026,9,15), notes:"Biweekly Fri · $4,017 net · 401k $1,125/pay deducted · verified from pay stub" },
    // Paychecks 21–26 (Oct 9 – Dec 25 2026): 401k maxed → net $4,883
    { id:"jsal_b", name:"Jennie Salary (401k maxed)", amount:4883, dayOfWeek:5, account:"chase_in", category:"income", active:true, frequency:"biweekly",
      startDate: new Date(2026,9,16), endDate: new Date(2026,10,26), notes:"401k maxed ~Oct 16 · +$866/pay" },
    // Phase 3: pays 24-26 (Nov 27 - Dec 25) - SS + 401k both maxed (+$1,331/pay vs phase 1)
    { id:"jsal_c", name:"Jennie Salary (SS + 401k maxed)", amount:5348, dayOfWeek:5, account:"chase_in", category:"income", active:true, frequency:"biweekly",
      startDate: new Date(2026,10,27), endDate: new Date(2026,11,31), notes:"SS + 401k both maxed ~Nov 27" },
    // 2027: new 401k cycle → back to $4,017
    { id:"jsal_2027", name:"Jennie Salary", amount:4017, dayOfWeek:5, account:"chase_in", category:"income", active:true, frequency:"biweekly",
      startDate: new Date(2027,0,9), notes:"2027 – new 401k cycle, pre-max rate · first pay Jan 9" },
    // Bonus: $58,500 gross → ~$24,633 net
    // Aggregate withholding: bonus + regular pay annualized → 37% fed bracket
    // 401k: 15% of bonus = $8,775 (paid Feb, before 401k maxed)
    // SS applies (Feb, minimal YTD wages). Verified: calc produced $23,249 on $55k actual ✓
    { id:"jbonus", name:"Jennie Bonus (2025 perf.)", amount:24633, specificDate: new Date(2027,1,13), account:"chase_in", category:"income", active:true, frequency:"once",
      notes:"$58.5k gross · aggregate withholding · 401k $8,775 deducted · ~$24,633 net · paid ~Feb 13 2027" },

    // MORTGAGE
    { id:"mort_xfer", name:"Mortgage Transfer → Webster", amount:6290, dayOfMonth:25, account:"chase_out", category:"mortgage", active:true, frequency:"monthly", notes:"Transfer to Webster on 25th · pays following month's mortgage" },
    { id:"mort_pay",  name:"Mortgage Payment (Webster)", amount:6290, dayOfMonth:5,  account:"webster_out", category:"mortgage", active:true, frequency:"monthly", notes:"Paid from Webster on 5th" },

    // CAR & INSURANCE
    { id:"car",    name:"VW Tiguan Car Payment", amount:617.45, dayOfMonth:1, account:"chase_out", category:"auto", active:true, frequency:"monthly" },
    { id:"carins", name:"Car Insurance",         amount:636.46, dayOfMonth:1, account:"chase_out", category:"insurance", active:true, frequency:"monthly" },
    { id:"life_jennie", name:"Life Insurance (Jennie)", amount:1772.42, dayOfMonth:12, account:"chase_out", category:"insurance", active:true, frequency:"annual", monthOfYear:0, notes:"Annual · Jan 12 · Chase" },
    { id:"life_ben",    name:"Life Insurance (Ben)",    amount:2409.17, dayOfMonth:18, account:"chase_out", category:"insurance", active:true, frequency:"annual", monthOfYear:11, notes:"Annual · Dec 18 · Chase" },

    // AU PAIR
    { id:"aupair_stipend", name:"Au Pair Stipend (Wednesday)", amount:250, dayOfWeek:3, account:"chase_out", category:"childcare", active:true, frequency:"weekly",
      endDate: new Date(2026,3,25), notes:"Current au pair ends ~Apr 25" },
    { id:"aupair_fee", name:"Au Pair Program Fee (New)", amount:10000, specificDate: new Date(2026,6,1), account:"amex", category:"childcare", active:true, frequency:"once",
      notes:"⚠️ Confirm exact amount and date" },
    { id:"aupair_new", name:"New Au Pair Stipend (Wednesday)", amount:250, dayOfWeek:3, account:"chase_out", category:"childcare", active:true, frequency:"weekly",
      startDate: new Date(2026,7,6), notes:"Scenario: $200 or $300/wk" },

    // DAYCARE - Magical Beginnings ($450/wk per child)
    { id:"mb_evie_a", name:"Magical Beginnings – Evie", amount:450, dayOfWeek:5, account:"amex", category:"childcare", active:true, frequency:"weekly",
      endDate: new Date(2026,5,12), notes:"$450/wk · pauses for camp Jun 19" },
    // Camp gap: Jun 19 – Aug 14 (Evie at Rolling Hills camp, billed through CC statement)
    { id:"mb_evie_b", name:"Magical Beginnings – Evie", amount:450, dayOfWeek:5, account:"amex", category:"childcare", active:true, frequency:"weekly",
      startDate: new Date(2026,7,21), endDate: new Date(2027,5,30), notes:"$450/wk · resumes Aug 21 after camp" },
    { id:"mb_hugh", name:"Magical Beginnings – Hugh (Friday)", amount:450, dayOfWeek:5, account:"amex", category:"childcare", active:true, frequency:"weekly",
      startDate: new Date(2026,8,1), endDate: new Date(2027,5,30), notes:"$450/wk · starts Sep 2026, ends June 2027" },

    // UTILITIES - Cash
    // Standard Oil: heating oil fills billed end-of-month, paid by 25th of following month
    // Fill estimate: $1,100-$1,400 (using $1,250 midpoint). Service fee $670 due Jul 25.
    // Recent fills: Oct 2025, Dec 2025, Jan 2026. Pattern: Oct, Dec, Jan/Feb/Mar depending on temps.
    { id:"util_ever",   name:"Eversource",      amount:380,  dayOfMonth:19, account:"chase_out", category:"utilities", active:true, frequency:"monthly", monthlyAmounts:[380,350,310,290,320,480,580,650,500,350,290,255], notes:"Seasonal · Dec ~$255 low · Aug ~$650 high · paid 19th Chase" },
    // Internet moved to Amex (Frontier $100/mo). Trash replaced by Country Waste (bimonthly, Amex).
    { id:"util_mobile", name:"T-Mobile",        amount:200,  dayOfMonth:20, account:"chase_out", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_clean",  name:"Cleaning Authority", amount:287, dayOfMonth:8, account:"amex", category:"utilities", active:true, frequency:"monthly", notes:"Billed when they clean · typically 6th-11th" },
    // Home Services removed — replaced by House Manager Northeast ($319/19th/Amex)

    // UTILITIES - Credit (Amex)
    // Streaming replaced by Netflix ($19/3rd) and Spotify ($20/28th) — listed below
    { id:"util_pelo",   name:"Peloton",           amount:47,  dayOfMonth:26, account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_cross",  name:"Crossfit",          amount:272, dayOfMonth:1,  account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_ymca",   name:"YMCA",              amount:152, dayOfMonth:1,  account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_simplisafe", name:"SimpliSafe",    amount:34,  dayOfMonth:6,  account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_frontier",   name:"Frontier (Internet)", amount:100, dayOfMonth:26, account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_housemgr",   name:"House Manager Northeast", amount:319, dayOfMonth:19, account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_subaru",     name:"Subaru App Service", amount:14.90, dayOfMonth:28, account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_netflix",    name:"Netflix",       amount:19,  dayOfMonth:3,  account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_spotify",    name:"Spotify",       amount:20,  dayOfMonth:28, account:"amex", category:"utilities", active:true, frequency:"monthly" },
    { id:"util_trash",      name:"Country Waste Services", amount:119, account:"amex", category:"utilities", active:true, frequency:"bimonthly",
      specificDate: new Date(2026,1,4), notes:"Every other month · last paid Feb 4 · next ~Apr 4" },
    // Mosquito Squad: 3 treatments/year on Amex — modeled as one-offs based on 2025 actuals
    { id:"util_land",   name:"Landscaping",     amount:280,  dayOfMonth:15, account:"chase_out", category:"utilities", active:true, frequency:"monthly", monthlyAmounts:[0,0,965,280,280,280,280,280,280,965,0,0], notes:"Apr-Sep $280/mo · Oct $965 (cleanup) · paid 15th Chase" },

    // GAS
    { id:"gas", name:"Gas", amount:50, dayOfWeek:3, account:"amex", category:"utilities", active:true, frequency:"weekly", notes:"~$50/week · Amex · every Wednesday" },

    // COUNTRY CLUB - Rolling Hills
    // Statement closes end of month, paid 25th of following month from Chase
    // Components: dues $2,750/mo (Jan-Jul only) + admin $153.45/mo + assessment $400/mo
    // + ~10% of $2,500 dining budget most months, 20% summer (Jun-Aug), 0% in Feb
    // monthlyAmounts = payment made on 25th for prior month's statement
    // i.e. index 0 (Jan payment) = Dec statement = $803.45
    //      index 1 (Feb payment) = Jan statement = $3,553.45, etc.
    { id:"cc_dues", name:"Rolling Hills CC", amount:3553.45, dayOfMonth:25, account:"chase_out", category:"country_club", active:true, frequency:"monthly",
      monthlyAmounts:[803.45,3553.45,3303.45,3553.45,3553.45,3553.45,5603.45,7403.45,2853.45,803.45,803.45,803.45],
      notes:"Stmt end-of-month · paid 25th following month · dues $2,750 Jan-Jul + admin $153.45 + assessment $400 + CC dining + Dean & Evie camp Jun-Aug ($900/wk)" },

    // DISCRETIONARY (credit - Amex)
    { id:"grocery_amex", name:"Groceries (Amex)", amount:640, dayOfWeek:3, account:"amex", category:"discretionary", active:true, frequency:"weekly", notes:"80% of $800/wk · every Wednesday" },
    { id:"grocery_visa", name:"Groceries (Visa)", amount:160, dayOfWeek:3, account:"visa", category:"discretionary", active:true, frequency:"weekly", notes:"20% of $800/wk · every Wednesday" },
    { id:"dining", name:"Dining Out (Amex)", amount:442, dayOfWeek:3, account:"amex", category:"discretionary", active:true, frequency:"weekly",
      monthlyAmounts:[442, 500, 442, 442, 442, 385, 385, 385, 442, 442, 442, 442],
      notes:"$500/wk budget · weekly Wed · Jun-Aug lower (CC dining at club)" },
    { id:"shopping_amex", name:"Shopping (Amex)", amount:280, dayOfWeek:3, account:"amex", category:"discretionary", active:true, frequency:"weekly", notes:"70% of $400/wk · every Wednesday" },
    { id:"shopping_visa", name:"Shopping (Visa)", amount:120, dayOfWeek:3, account:"visa", category:"discretionary", active:true, frequency:"weekly", notes:"30% of $400/wk · every Wednesday" },

    // LIFE INSURANCE
    

    // 529 CONTRIBUTIONS — annual lump sum ~Dec 26 after Bernstein bonus (mid-to-late Dec)
    // $10k aggregate split across 3 accounts; amount TBD each year
    { id:"529_2026", name:"529 Contributions (annual)", amount:10000, dayOfMonth:26, account:"chase_out", category:"savings", active:true, frequency:"annual", monthOfYear:11, notes:"~Dec 26 · after Bernstein bonus · $10k aggregate across Dean/Evie/Hugh" },
  ],

  oneOffExpenses: [
    // Standard Oil payments (fill deliveries → paid 25th of following month)
    // 2025 TAX YEAR SETTLEMENTS
    { id:"tax_fed_2025", name:"Federal Tax Payment (2025)", amount:30000, specificDate: new Date(2026,3,15), account:"chase_out", category:"taxes", active:true, frequency:"once", notes:"2025 federal tax due · per accountant" },
    { id:"tax_ct_2025", name:"CT State Tax Payment (2025)", amount:2000, specificDate: new Date(2026,3,15), account:"chase_out", category:"taxes", active:true, frequency:"once", notes:"2025 CT state tax due · per accountant" },
    { id:"tax_ny_refund", name:"NY State Tax Refund (2025)", amount:10000, specificDate: new Date(2026,5,1), account:"chase_in", category:"income", active:true, frequency:"once", notes:"2025 NY refund est. ~$10k · typically 6-8 wks after filing" },

    // Ben Bernstein Bonus (mid-to-late December)
    // $275k gross: 25% ($68,750) deferred as AB stock (no cash now, taxable when vests)
    // 75% ($206,250) cash: 37% fed + 9.62% NY state + Medicare + Add'l Medicare
    // No SS (salary already maxed $176,100 wage base), no 401k (already maxed)
    { id:"ben_bonus", name:"Ben Bonus (Bernstein)", amount:104480, specificDate: new Date(2026,11,20), account:"chase_in", active:true, frequency:"once", category:"income",
      notes:"$275k gross · $68,750 deferred AB stock · $206,250 cash · 49.3% effective tax rate · net $104,480" },
    // Rolling Hills capital assessment — final one
    // Mosquito Squad 2026 (based on 2025 actuals: Mar 19, Apr 30, Jun 11)
    // Car property tax — annual, July, Chase checking
    { id:"car_tax_2026", name:"Car Property Tax", amount:1000, specificDate: new Date(2026,6,15), account:"chase_out", category:"auto", active:true, frequency:"once", notes:"Annual · est. $1,000 · July 2026" },
    { id:"car_tax_2027", name:"Car Property Tax", amount:1000, specificDate: new Date(2027,6,15), account:"chase_out", category:"auto", active:true, frequency:"once", notes:"Annual · est. $1,000 · July 2027" },
    { id:"mosq_mar26", name:"Mosquito Squad – Treatment 1", amount:634.91, specificDate: new Date(2026,2,19), account:"amex", category:"utilities", active:true, frequency:"once", notes:"2025 actual: Mar 19 · $634.91" },
    { id:"mosq_apr26", name:"Mosquito Squad – Treatment 2", amount:634.91, specificDate: new Date(2026,3,30), account:"amex", category:"utilities", active:true, frequency:"once", notes:"2025 actual: Apr 30 · $634.91" },
    { id:"mosq_jun26", name:"Mosquito Squad – Treatment 3", amount:634.91, specificDate: new Date(2026,5,11), account:"amex", category:"utilities", active:true, frequency:"once", notes:"2025 actual: Jun 11 · $634.91" },
    { id:"cc_capital", name:"Rolling Hills Capital Assessment (final)", amount:2667, specificDate: new Date(2027,1,25), account:"chase_out", category:"country_club", active:true, frequency:"once", notes:"Jan 2027 statement → paid Feb 25 2027 · final capital assessment" },
    { id:"oil_jan26",  name:"Standard Oil – Jan fill",      amount:1250, specificDate: new Date(2026,1,25), account:"chase_out", category:"utilities", active:true, frequency:"once", notes:"Jan 2026 fill · est. $1,100-$1,400" },
    { id:"oil_feb26",  name:"Standard Oil – Feb fill",      amount:1250, specificDate: new Date(2026,2,25), account:"chase_out", category:"utilities", active:true, frequency:"once", notes:"Feb 2026 fill (likely · CT still cold)" },
    { id:"oil_mar26",  name:"Standard Oil – Mar fill",      amount:1250, specificDate: new Date(2026,3,25), account:"chase_out", category:"utilities", active:true, frequency:"once", notes:"Mar 2026 fill (possible · delete if no fill)" },
    { id:"oil_svc26",  name:"Standard Oil – Annual Service",amount:670,  specificDate: new Date(2026,6,25), account:"chase_out", category:"utilities", active:true, frequency:"once", notes:"Annual service fee · June statement → Jul 25" },
    { id:"oil_oct26",  name:"Standard Oil – Oct fill",      amount:1250, specificDate: new Date(2026,10,25), account:"chase_out", category:"utilities", active:true, frequency:"once", notes:"Oct 2026 fill (expected)" },
    { id:"oil_dec26",  name:"Standard Oil – Dec fill",      amount:1250, specificDate: new Date(2027,0,25), account:"chase_out", category:"utilities", active:true, frequency:"once", notes:"Dec 2026 fill (expected) → paid Jan 25 2027" },
    { id:"boca_hotel",  name:"Boca Raton Hotel",       amount:5000, specificDate: new Date(2026,3,19), account:"amex", category:"vacation", active:true, frequency:"once", notes:"Mid-April Boca Raton trip" },
    { id:"boca_car",    name:"Boca Raton Rental Car",   amount:600,  specificDate: new Date(2026,3,14), account:"amex", category:"vacation", active:true, frequency:"once", notes:"⚠️ Estimate – not yet booked (5 days)" },
    { id:"boca_dining", name:"Boca Raton Extra Dining",  amount:800,  specificDate: new Date(2026,3,17), account:"amex", category:"vacation", active:true, frequency:"once", notes:"⚠️ Estimate" },
  ],
  chatHistory: [],
  pendingChange: null,
};

// ─── HELPERS ──────────────────────────────────────────────────────────────
const fmt = (n) => new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0}).format(n);
const fmtD = (d) => d.toLocaleDateString("en-US",{month:"short",day:"numeric"});
const fmtFull = (d) => d.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"});
const addDays = (d,n) => { const r=new Date(d); r.setDate(r.getDate()+n); return r; };
const isSameDay = (a,b) => a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()&&a.getDate()===b.getDate();
const isAfterOrSame = (a,b) => a >= b;
const isBefore = (a,b) => a < b;

// Generate all transactions for a date range
function generateTransactions(state, startDate, endDate) {
  const txns = [];
  const { recurringBills, oneOffExpenses, stipendScenario } = state;

  // One-off expenses
  for (const e of oneOffExpenses) {
    const d = new Date(e.specificDate || e.date);
    if (d >= startDate && d <= endDate) {
      const isIncome = e.account === "chase_in";
      txns.push({ date: d, name: e.name, amount: e.amount, account: e.account, category: e.category, type: isIncome ? "income" : "expense", id: e.id, oneOff: true });
    }
  }

  // Iterate each day
  let cur = new Date(startDate);
  while (cur <= endDate) {
    const dow = cur.getDay(); // 0=Sun
    const dom = cur.getDate();
    const month = cur.getMonth();
    const year = cur.getFullYear();

    for (const bill of recurringBills) {
      if (!bill.active) continue;
      const start = bill.startDate ? new Date(bill.startDate) : new Date(2020,0,1);
      const end   = bill.endDate   ? new Date(bill.endDate)   : new Date(2040,0,1);
      if (cur < start || cur > end) continue;

      let match = false;
      let amount = bill.monthlyAmounts ? (bill.monthlyAmounts[month] ?? 0) : bill.amount;

      // Apply stipend scenario
      if (bill.id === "aupair_stipend" || bill.id === "aupair_new") {
        amount = stipendScenario;
      }

      if (bill.frequency === "monthly" && dom === (bill.dayOfMonth || 1)) match = true;
      if (bill.frequency === "semimonthly" && dom === bill.dayOfMonth) match = true;
      if (bill.frequency === "weekly" && bill.dayOfWeek === dow) match = true;
      if (bill.frequency === "biweekly" && bill.dayOfWeek === dow) {
        // biweekly: every other occurrence of that weekday from a reference date
        // Ben (Thu, dayOfWeek:4) anchors to Jan 1 2026; Jennie (Fri, dayOfWeek:5) anchors to Jan 9 2026
        // Verified: Ben last paid Feb 26, Jennie last paid Feb 20 — alternating weeks, 1 week apart
        const defaultRef = bill.dayOfWeek === 4 ? new Date(2026,0,1) : new Date(2026,0,9);
        const ref = bill.startDate ? new Date(bill.startDate) : defaultRef;
        const diffDays = Math.round((cur - ref) / (1000*60*60*24));
        if (diffDays >= 0 && diffDays % 14 === 0) match = true;
      }
      if (bill.frequency === "monthly_last_weekday" && bill.dayOfWeek === dow) {
        // last occurrence of that weekday in the month
        const nextWeek = addDays(cur, 7);
        if (nextWeek.getMonth() !== month) match = true; // no same-weekday in next 7 days = last one
      }
      if (bill.frequency === "bimonthly" && bill.specificDate) {
        // every other month from a reference date
        const refDate = new Date(bill.specificDate);
        const monthsDiff = (year - refDate.getFullYear()) * 12 + (month - refDate.getMonth());
        if (monthsDiff >= 0 && monthsDiff % 2 === 0) {
          // find the closest weekday in the 3rd-6th window — use dom 4 as default midpoint
          if (dom === 4) match = true;
        }
      }
      if (bill.frequency === "once" && bill.specificDate && isSameDay(cur, new Date(bill.specificDate))) match = true;
      if (bill.frequency === "annual" && bill.monthOfYear === month && dom === (bill.dayOfMonth||1)) match = true;

      if (match && amount !== 0) {
        const isIncome = bill.account === "chase_in";
        txns.push({
          date: new Date(cur),
          name: bill.name,
          amount: Math.abs(amount),
          account: bill.account,
          category: bill.category,
          type: isIncome ? "income" : "expense",
          id: bill.id,
          notes: bill.notes,
        });
      }
    }
    cur = addDays(cur, 1);
  }

  txns.sort((a,b) => a.date - b.date);
  return txns;
}

// Build daily balance forecast including CC statement logic
function buildForecast(state, days = 180) {
  const startDate = new Date(TODAY);
  const endDate = addDays(startDate, days);

  const txns = generateTransactions(state, startDate, endDate);

  // CC state
  let amexAccruing = state.amexAccruing;
  let amexStatement = state.amexOutstanding; // current unpaid statement
  let visaAccruing  = state.visaAccruing || 0;
  let visaStatement = state.visaOutstanding;

  let chaseBalance = state.chaseBalance;

  const dailyData = [];
  let cur = new Date(startDate);

  while (cur <= endDate) {
    const dom = cur.getDate();
    const month = cur.getMonth();
    const dayTxns = txns.filter(t => isSameDay(t.date, cur));

    const events = [];

    // ── Amex statement closes on 11th
    if (dom === 11 && cur > startDate) {
      const newStatement = amexAccruing;
      events.push({ type:"cc_close", label:`Amex statement closes: ${fmt(newStatement)}`, amount: newStatement, account:"amex", dir:"neutral" });
      amexStatement = newStatement;
      amexAccruing = 0;
    }

    // ── Amex payment due 6th (pays prior month's statement)
    if (dom === 6 && amexStatement > 0) {
      events.push({ type:"cc_pay", label:`Amex payment: ${fmt(amexStatement)}`, amount: amexStatement, account:"chase_out", dir:"out" });
      chaseBalance -= amexStatement;
      amexStatement = 0;
    }

    // ── Visa statement closes 21st
    if (dom === 21 && cur > startDate) {
      const newStatement = visaAccruing;
      events.push({ type:"cc_close", label:`Visa statement closes: ${fmt(newStatement)}`, amount: newStatement, account:"visa", dir:"neutral" });
      visaStatement = newStatement;
      visaAccruing = 0;
    }

    // ── Visa payment due 18th
    if (dom === 18 && visaStatement > 0) {
      events.push({ type:"cc_pay", label:`Visa payment: ${fmt(visaStatement)}`, amount: visaStatement, account:"chase_out", dir:"out" });
      chaseBalance -= visaStatement;
      visaStatement = 0;
    }

    // ── Regular transactions
    for (const t of dayTxns) {
      if (t.type === "income") {
        chaseBalance += t.amount;
        events.push({ ...t, dir:"in", label:`${t.name}: +${fmt(t.amount)}` });
      } else if (t.account === "amex") {
        amexAccruing += t.amount;
        events.push({ ...t, dir:"amex", label:`${t.name}: ${fmt(t.amount)} → Amex` });
      } else if (t.account === "visa") {
        visaAccruing += t.amount;
        events.push({ ...t, dir:"visa", label:`${t.name}: ${fmt(t.amount)} → Visa` });
      } else if (t.account === "webster_out") {
        // Webster pays mortgage — Webster balance is funded by Chase transfer on 25th
        // Don't double-deduct from Chase here; the chase_out transfer on 25th already covers it
        events.push({ ...t, dir:"out", label:`${t.name}: -${fmt(t.amount)} (Webster)` });
      } else {
        // chase_out and all other accounts
        chaseBalance -= t.amount;
        events.push({ ...t, dir:"out", label:`${t.name}: -${fmt(t.amount)}` });
      }
    }

    dailyData.push({
      date: new Date(cur),
      chaseBalance: Math.round(chaseBalance * 100) / 100,
      amexAccruing: Math.round(amexAccruing * 100) / 100,
      amexStatement: Math.round(amexStatement * 100) / 100,
      visaAccruing: Math.round(visaAccruing * 100) / 100,
      visaStatement: Math.round(visaStatement * 100) / 100,
      events,
    });

    cur = addDays(cur, 1);
  }

  return dailyData;
}

// ─── CHART ────────────────────────────────────────────────────────────────
function MiniChart({ data, width = 600, height = 120 }) {
  if (!data.length) return null;
  const vals = data.map(d => d.chaseBalance);
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const range = max - min || 1;
  const pad = 8;
  const W = width - pad*2, H = height - pad*2;

  const pts = data.map((d,i) => {
    const x = pad + (i / (data.length-1)) * W;
    const y = pad + H - ((d.chaseBalance - min) / range) * H;
    return `${x},${y}`;
  }).join(" ");

  const zeroY = min < 0 ? pad + H - ((0 - min) / range) * H : H + pad + 1;

  return (
    <svg width="100%" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3"/>
          <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.02"/>
        </linearGradient>
      </defs>
      {min < 0 && <line x1={pad} y1={zeroY} x2={W+pad} y2={zeroY} stroke="#ef4444" strokeWidth="1" strokeDasharray="4,4" opacity="0.5"/>}
      <polygon points={`${pad},${H+pad} ${pts} ${W+pad},${H+pad}`} fill="url(#chartGrad)"/>
      <polyline points={pts} fill="none" stroke="#3b82f6" strokeWidth="2" strokeLinejoin="round"/>
    </svg>
  );
}

// ─── MAIN APP ────────────────────────────────────────────────────────────
export default function App() {
  const [state, setState] = useState(() => {
    try {
      const saved = localStorage.getItem("cashflow_v4");
      if (saved) {
        const parsed = JSON.parse(saved);
        // Re-hydrate Date objects in oneOffExpenses (JSON stringify loses Date type)
        if (parsed.oneOffExpenses) {
          parsed.oneOffExpenses = DEFAULT_STATE.oneOffExpenses;
        }
        if (parsed.recurringBills) {
          parsed.recurringBills = DEFAULT_STATE.recurringBills;
        }
        return { ...DEFAULT_STATE, ...parsed,
          oneOffExpenses: DEFAULT_STATE.oneOffExpenses,
          recurringBills: DEFAULT_STATE.recurringBills };
      }
    } catch {}
    return DEFAULT_STATE;
  });

  const [chatInput, setChatInput] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const [selectedDay, setSelectedDay] = useState(null);
  const [viewMode, setViewMode] = useState("timeline"); // timeline | monthly | bills
  const chatEndRef = useRef(null);
  const chatInputRef = useRef(null);

  // Persist state
  useEffect(() => {
    try { localStorage.setItem("cashflow_v4", JSON.stringify(state)); } catch {}
  }, [state]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior:"smooth" });
  }, [state.chatHistory]);

  const forecast = useMemo(() => buildForecast(state, 180), [state]);

  // Group by month for monthly view
  const monthlyGroups = useMemo(() => {
    const groups = {};
    for (const d of forecast) {
      const key = `${d.date.getFullYear()}-${d.date.getMonth()}`;
      if (!groups[key]) groups[key] = { label: d.date.toLocaleDateString("en-US",{month:"long",year:"numeric"}), days:[], endBalance: 0 };
      groups[key].days.push(d);
      groups[key].endBalance = d.chaseBalance;
    }
    return Object.values(groups);
  }, [forecast]);

  // Find low balance days
  const lowestBalance = useMemo(() => forecast.reduce((a,b) => b.chaseBalance < a.chaseBalance ? b : a, forecast[0]), [forecast]);

  // ── CHAT ────────────────────────────────────────────────────────────────
  const sendMessage = useCallback(async () => {
    const msg = chatInput.trim();
    if (!msg) return;
    setChatInput("");
    setIsThinking(true);

    const newHistory = [...state.chatHistory, { role:"user", content: msg }];
    setState(s => ({ ...s, chatHistory: newHistory }));

    const systemPrompt = `You are a financial assistant managing a personal cash flow forecasting app for Ben, a family in Wilton, CT. You help edit financial data.

Current financial snapshot:
- Chase checking balance: $${state.chaseBalance.toLocaleString()}
- Webster checking balance: $${state.websterBalance.toLocaleString()}
- Bernstein money market balance: $${state.mmBalance.toLocaleString()}
- Amex current statement (unpaid): $${state.amexOutstanding.toLocaleString()}
- Amex accruing (current period): $${state.amexAccruing.toLocaleString()}
- Visa outstanding: $${state.visaOutstanding.toLocaleString()}
- Au pair stipend scenario: $${state.stipendScenario}/week

Recurring bills summary:
${state.recurringBills.map(b => `- ${b.name}: $${b.amount} | ${b.frequency} | account:${b.account}`).join('\n')}

One-off expenses: ${state.oneOffExpenses.length} items

When the user requests a change, respond with:
1. A clear plain-English summary of what you understood and exactly what you will change
2. Then a JSON block in this exact format (no markdown fences, just raw JSON on its own line):
PROPOSED_CHANGE: {"type":"...", "data":{...}}

Change types and data formats:
- Update recurring bill: {"type":"update_bill","data":{"id":"bill_id","field":"amount|dayOfMonth|endDate|startDate|active|amount|notes","value":"new_value","scope":"one_month|all_future","month":0,"year":2026}}
- Add recurring bill: {"type":"add_bill","data":{"name":"...","amount":0,"dayOfMonth":1,"account":"chase_out|amex|visa|chase_in","category":"...","frequency":"monthly|weekly|once|annual","startDate":"2026-03-01","endDate":null,"notes":"..."}}
- Delete bill: {"type":"delete_bill","data":{"id":"bill_id"}}
- Add one-off: {"type":"add_oneoff","data":{"name":"...","amount":0,"date":"2026-04-15","account":"chase_out|amex|visa","category":"...","notes":"..."}}
- Update balance: {"type":"update_balance","data":{"account":"chase|amex_outstanding|amex_accruing|visa","value":0}}
- Update stipend scenario: {"type":"update_stipend","data":{"amount":200}}

Bill IDs: ${state.recurringBills.map(b=>b.id).join(', ')}

If the user's request is unclear, ask for clarification. Keep responses concise. If no change is needed (just a question), answer conversationally without the PROPOSED_CHANGE line.`;

    // Rule-based parser — handles common update patterns without API call
    try {
      const lower = msg.toLowerCase();
      let reply = "";
      let pendingChange = null;

      // Helper: extract dollar amount from message
      const extractAmt = (str) => {
        const m = str.match(/\$?([\d,]+(?:\.\d{1,2})?)/);
        return m ? parseFloat(m[1].replace(/,/g,"")) : null;
      };

      // Balance updates
      if ((lower.includes("amex") || lower.includes("american express")) && (lower.includes("balance") || lower.includes("statement") || lower.includes("total"))) {
        // Try to extract statement vs accruing
        const stmtMatch = msg.match(/statement[^$\d]*\$?([\d,]+(?:\.\d{1,2})?)/i);
        const totalMatch = msg.match(/total[^$\d]*\$?([\d,]+(?:\.\d{1,2})?)/i) || msg.match(/\$?([\d,]+(?:\.\d{1,2})?)/);
        const accruingMatch = msg.match(/accruing[^$\d]*\$?([\d,]+(?:\.\d{1,2})?)/i) || msg.match(/current period[^$\d]*\$?([\d,]+(?:\.\d{1,2})?)/i);

        if (stmtMatch && accruingMatch) {
          const stmt = parseFloat(stmtMatch[1].replace(/,/g,""));
          const acc = parseFloat(accruingMatch[1].replace(/,/g,""));
          reply = `I'll update the Amex statement balance to $${stmt.toLocaleString()} and accruing balance to $${acc.toLocaleString()}.`;
          pendingChange = { type:"update_balance_multi", data:[
            { account:"amex_outstanding", value: stmt },
            { account:"amex_accruing", value: acc },
          ]};
        } else if (stmtMatch) {
          const amt = parseFloat(stmtMatch[1].replace(/,/g,""));
          reply = `I'll update the Amex statement balance (to be paid in March) to $${amt.toLocaleString()}.`;
          pendingChange = { type:"update_balance", data:{ account:"amex_outstanding", value: amt }};
        } else {
          const amt = extractAmt(msg);
          if (amt) {
            reply = `I'll update the Amex total balance to $${amt.toLocaleString()}.`;
            pendingChange = { type:"update_balance", data:{ account:"amex_outstanding", value: amt }};
          }
        }
      } else if (lower.includes("visa") && lower.includes("balance")) {
        const amt = extractAmt(msg);
        if (amt) { reply = `I'll update the Visa balance to $${amt.toLocaleString()}.`; pendingChange = { type:"update_balance", data:{ account:"visa", value: amt }}; }
      } else if (lower.includes("chase") && (lower.includes("balance") || lower.includes("checking"))) {
        const amt = extractAmt(msg);
        if (amt) { reply = `I'll update the Chase checking balance to $${amt.toLocaleString()}.`; pendingChange = { type:"update_balance", data:{ account:"chase", value: amt }}; }
      } else if (lower.includes("webster") && lower.includes("balance")) {
        const amt = extractAmt(msg);
        if (amt) { reply = `I'll update the Webster balance to $${amt.toLocaleString()}.`; pendingChange = { type:"update_balance", data:{ account:"webster", value: amt }}; }
      } else if ((lower.includes("money market") || lower.includes("bernstein mm")) && lower.includes("balance")) {
        const amt = extractAmt(msg);
        if (amt) { reply = `I'll update the Bernstein money market balance to $${amt.toLocaleString()}.`; pendingChange = { type:"update_balance", data:{ account:"mm", value: amt }}; }
      // Stipend updates
      } else if (lower.includes("stipend") || (lower.includes("au pair") && lower.includes("week"))) {
        const amt = extractAmt(msg);
        if (amt) { reply = `I'll update the au pair stipend to $${amt}/week.`; pendingChange = { type:"update_stipend", data:{ amount: amt }}; }
      // Bill amount updates
      } else if (lower.includes("update") || lower.includes("change") || lower.includes("set")) {
        // Try to match a bill name and amount
        const bills = state.recurringBills;
        const matched = bills.find(b => lower.includes(b.name.toLowerCase().split(" ")[0].toLowerCase()) ||
                                        lower.includes(b.id.toLowerCase()));
        const amt = extractAmt(msg);
        if (matched && amt) {
          reply = `I'll update ${matched.name} to $${amt.toLocaleString()}.`;
          pendingChange = { type:"update_bill", data:{ id: matched.id, field:"amount", value: amt }};
        } else {
          reply = `I can update balances and bill amounts. Try: "Chase balance is $75,000" or "Update CrossFit to $280/month". What would you like to change?`;
        }
      } else {
        reply = `I can help update balances and bills directly. Try:
• "Amex statement balance is $21,694"
• "Chase balance is $75,000"
• "Visa balance is $1,200"
• "Update [bill name] to $[amount]"
• "Au pair stipend is $250/week"`;
      }

      if (!reply) reply = "I didn't catch that — could you rephrase? E.g. 'Amex statement balance is $21,694'";

      setState(s => ({
        ...s,
        chatHistory: [...newHistory, { role:"assistant", content: reply }],
        pendingChange,
      }));
    } catch (e) {
      setState(s => ({
        ...s,
        chatHistory: [...newHistory, { role:"assistant", content:`Error: ${e.message}` }],
      }));
    }
    setIsThinking(false);
  }, [chatInput, state]);

  const applyChange = useCallback(() => {
    const c = state.pendingChange;
    if (!c) return;

    setState(s => {
      let newState = { ...s, pendingChange: null };
      const { type, data } = c;

      if (type === "update_bill") {
        newState.recurringBills = s.recurringBills.map(b => {
          if (b.id !== data.id) return b;
          let val = data.value;
          if (data.field === "amount") val = parseFloat(val);
          if (data.field === "active") val = Boolean(val);
          if (data.field === "endDate" || data.field === "startDate") val = val ? new Date(val) : null;
          return { ...b, [data.field]: val };
        });
      } else if (type === "add_bill") {
        const newBill = { ...data, id: `bill_${Date.now()}`, active:true };
        if (newBill.startDate) newBill.startDate = new Date(newBill.startDate);
        if (newBill.endDate) newBill.endDate = new Date(newBill.endDate);
        newState.recurringBills = [...s.recurringBills, newBill];
      } else if (type === "delete_bill") {
        newState.recurringBills = s.recurringBills.filter(b => b.id !== data.id);
      } else if (type === "add_oneoff") {
        newState.oneOffExpenses = [...s.oneOffExpenses, { ...data, id:`oneoff_${Date.now()}`, date: new Date(data.date) }];
      } else if (type === "update_balance" || type === "update_balance_multi") {
        const updates = type === "update_balance_multi" ? data : [data];
        for (const d of updates) {
          if (d.account === "chase") newState.chaseBalance = d.value;
          if (d.account === "webster") newState.websterBalance = d.value;
          if (d.account === "mm") newState.mmBalance = d.value;
          if (d.account === "amex_outstanding") newState.amexOutstanding = d.value;
          if (d.account === "amex_accruing") newState.amexAccruing = d.value;
          if (d.account === "visa") newState.visaOutstanding = d.value;
        }
      } else if (type === "update_stipend") {
        newState.stipendScenario = data.amount;
        newState.recurringBills = s.recurringBills.map(b =>
          (b.id === "aupair_stipend" || b.id === "aupair_new") ? { ...b, amount: data.amount } : b
        );
      }

      const confirmMsg = { role:"assistant", content:`✅ Done! The change has been applied and the forecast has been updated.` };
      newState.chatHistory = [...s.chatHistory, confirmMsg];
      return newState;
    });
  }, [state.pendingChange]);

  const rejectChange = useCallback(() => {
    setState(s => ({
      ...s,
      pendingChange: null,
      chatHistory: [...s.chatHistory, { role:"assistant", content:"Got it — no changes made." }],
    }));
  }, []);

  // ── RENDER ───────────────────────────────────────────────────────────────
  const balColor = (n) => n < 5000 ? "#ef4444" : n < 20000 ? "#f59e0b" : "#10b981";

  const categoryColors = {
    income:"#10b981", mortgage:"#8b5cf6", auto:"#f97316",
    childcare:"#14b8a6", utilities:"#64748b", country_club:"#6366f1",
    discretionary:"#3b82f6", insurance:"#ec4899", savings:"#22c55e",
    vacation:"#f59e0b", cc_pay:"#ef4444", cc_close:"#f59e0b",
  };

  return (
    <div style={{ fontFamily:"'DM Sans', system-ui, sans-serif", background:"#0a0e1a", color:"#f1f5f9", minHeight:"100vh", display:"flex", flexDirection:"column" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; margin:0; padding:0; }
        ::-webkit-scrollbar { width:4px; height:4px; }
        ::-webkit-scrollbar-track { background:#111827; }
        ::-webkit-scrollbar-thumb { background:#1e3a5f; border-radius:2px; }
        .day-row:hover { background:#161d2e !important; }
        .tab-btn { transition: all 0.15s; }
        .tab-btn:hover { background:#1e2d45 !important; }
        .bill-row { transition: background 0.1s; }
        .bill-row:hover { background:#1a2540 !important; }
        .chat-input:focus { outline:none; border-color:#3b82f6 !important; }
        .send-btn:hover { background:#2563eb !important; }
        .confirm-btn:hover { opacity:0.9; }
        .flag { animation: pulse 2s infinite; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.6} }
      `}</style>

      {/* ── HEADER ── */}
      <div style={{ background:"#111827", borderBottom:"1px solid #1e2d45", padding:"16px 24px", display:"flex", alignItems:"center", justifyContent:"space-between", flexShrink:0 }}>
        <div>
          <div style={{ fontSize:20, fontWeight:700, letterSpacing:"-0.5px" }}>Cash Flow Forecast</div>
          <div style={{ fontSize:12, color:"#64748b", marginTop:2 }}>As of {fmtFull(TODAY)} · 6-month horizon</div>
        </div>
        <div style={{ display:"flex", gap:16, alignItems:"center" }}>
          {/* High-level category balances */}
          {(() => {
            const cashTotal = state.chaseBalance + state.websterBalance + state.mmBalance;
            const ccTotal = -(state.amexOutstanding + state.amexAccruing + state.visaOutstanding);
            const netCash = cashTotal + ccTotal;
            // Equity growth model: 7% annual = 0.5654% monthly
            const MONTHLY_R = Math.pow(1.07, 1/12) - 1;
            // Months elapsed since Feb 28 2026
            const mElapsed = (TODAY - new Date(2026,1,28)) / (1000*60*60*24*365/12);

            // Grow a balance with optional monthly contribution
            const grow = (bal, monthlyContrib = 0, months = mElapsed) => {
              let b = bal;
              for (let i = 0; i < Math.max(0, months); i++) b = b * (1 + MONTHLY_R) + monthlyContrib;
              return Math.round(b);
            };

            // Jennie 401k: $23,500/yr employee + $9,750 match = $33,250/yr → Athletic 401k
            // Ben 401k: $23,500/yr employee → AB 401k (match $15k comes Jan lump sum)
            const jMonthly401k = 33250 / 12;
            const bMonthly401k = 23500 / 12;

            const bernsteinJoint = grow(199573);
            const fidelityJennie = grow(3300);
            const invTotal = bernsteinJoint + fidelityJennie;

            const athleticBrewing401k = grow(189086, jMonthly401k);
            const benIRA = grow(350828);
            const jennieIRA = grow(295348);
            const ab401k = grow(163110, bMonthly401k);
            const northernTrust = grow(91420);
            const abUK = grow(11160);
            const retTotal = athleticBrewing401k + benIRA + jennieIRA + ab401k + northernTrust + abUK;

            // 529: $10k/yr lump sum in Dec, split evenly → ~$278/mo per child
            const monthly529 = (10000 / 3) / 12;
            const dean529 = grow(83915, monthly529);
            const evie529 = grow(18230, monthly529);
            const hugh529 = grow(11836, monthly529);
            const collegeTotal = dean529 + evie529 + hugh529;

            const categories = [
              { label:"Cash", val:netCash, color: balColor(netCash), accounts:[
                { label:"Chase", val:state.chaseBalance },
                { label:"Webster", val:state.websterBalance },
                { label:"Bernstein MM", val:state.mmBalance },
                { label:"Amex (owed)", val:-(state.amexOutstanding+state.amexAccruing) },
                { label:"Visa (owed)", val:-state.visaOutstanding },
              ]},
              { label:"Investments", val:invTotal, color:"#10b981", accounts:[
                { label:"Bernstein Joint", val:bernsteinJoint },
                { label:"Fidelity (Jennie)", val:fidelityJennie },
              ]},
              { label:"Retirement", val:retTotal, color:"#6366f1", accounts:[
                { label:"Athletic 401k (Jennie)", val:athleticBrewing401k },
                { label:"Ben IRA", val:benIRA },
                { label:"Jennie IRA", val:jennieIRA },
                { label:"AB 401k (Ben)", val:ab401k },
                { label:"Northern Trust UK", val:northernTrust },
                { label:"AB UK", val:abUK },
              ]},
              { label:"College (529)", val:collegeTotal, color:"#8b5cf6", accounts:[
                { label:"Dean", val:dean529 },
                { label:"Evie", val:evie529 },
                { label:"Hugh", val:hugh529 },
              ]},
              { label:"Company Stock", val:931378, color:"#f59e0b", accounts:[
                { label:"Athletic (vested)", val:766046 },
                { label:"AB Stock (deferred)", val:86893 },
                { label:"Athletic (unvested)", val:78439 },
              ]},
              { label:"Home Equity", val:746477, color:"#0891b2", accounts:[
                { label:"Home Value", val:1402000 },
                { label:"Cars", val:46200 },
                { label:"Mortgage", val:-672703 },
                { label:"VW Loan", val:-29021 },
              ]},
            ];
            return categories.map(cat => (
              <div key={cat.label} style={{ textAlign:"right", position:"relative", cursor:"pointer" }}
                onMouseEnter={e => { const el = e.currentTarget.querySelector(".acct-detail"); if(el) el.style.display="block"; }}
                onMouseLeave={e => { const el = e.currentTarget.querySelector(".acct-detail"); if(el) el.style.display="none"; }}>
                <div style={{ fontSize:11, color:"#64748b", textTransform:"uppercase", letterSpacing:"0.05em" }}>{cat.label}</div>
                <div style={{ fontSize:18, fontWeight:700, color:cat.color, fontFamily:"'DM Mono', monospace" }}>{fmt(cat.val)}</div>
                {/* Dropdown detail */}
                <div className="acct-detail" style={{ display:"none", position:"absolute", top:"100%", right:0, marginTop:6, background:"#1e2d45", border:"1px solid #2d3f60", borderRadius:8, padding:"10px 14px", zIndex:100, minWidth:180, textAlign:"left", boxShadow:"0 8px 24px rgba(0,0,0,0.5)" }}>
                  {cat.accounts.map(a => (
                    <div key={a.label} style={{ display:"flex", justifyContent:"space-between", gap:20, padding:"3px 0", fontSize:12, borderBottom:"1px solid #2d3f6030" }}>
                      <span style={{ color:"#94a3b8" }}>{a.label}</span>
                      <span style={{ color: a.val < 0 ? "#f87171" : "#e2e8f0", fontFamily:"'DM Mono',monospace", fontWeight:600 }}>{fmt(a.val)}</span>
                    </div>
                  ))}
                </div>
              </div>
            ));
          })()}
          {/* Stipend toggle */}
          <div style={{ background:"#161d2e", border:"1px solid #1e2d45", borderRadius:8, padding:"6px 12px" }}>
            <div style={{ fontSize:11, color:"#64748b", marginBottom:4 }}>Au Pair Stipend</div>
            <div style={{ display:"flex", gap:6 }}>
              {[200,300].map(amt => (
                <button key={amt} onClick={() => setState(s=>({...s,stipendScenario:amt}))}
                  style={{ padding:"3px 10px", borderRadius:5, border:"none", cursor:"pointer", fontSize:12, fontWeight:600,
                    background: state.stipendScenario===amt ? "#3b82f6" : "#1e2d45",
                    color: state.stipendScenario===amt ? "white" : "#64748b" }}>
                  ${amt}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── ALERT: LOW BALANCE ── */}
      {lowestBalance && lowestBalance.chaseBalance < 15000 && (
        <div className="flag" style={{ background:"#7f1d1d22", borderBottom:"1px solid #ef444430", padding:"8px 24px", fontSize:12, color:"#fca5a5", display:"flex", gap:8, alignItems:"center" }}>
          ⚠️ Projected low balance of {fmt(lowestBalance.chaseBalance)} on {fmtFull(lowestBalance.date)} — review upcoming payments
        </div>
      )}

      {/* ── TABS ── */}
      <div style={{ background:"#111827", borderBottom:"1px solid #1e2d45", padding:"0 24px", display:"flex", gap:4, flexShrink:0 }}>
        {[["timeline","📅 Timeline"],["monthly","📊 Monthly View"],["bills","🗂 All Bills"],["networth","📈 Net Worth"]].map(([id,label])=>(
          <button key={id} className="tab-btn" onClick={()=>setViewMode(id)}
            style={{ padding:"10px 16px", border:"none", cursor:"pointer", fontSize:13, fontWeight:500, borderRadius:"6px 6px 0 0",
              background: viewMode===id ? "#161d2e" : "transparent",
              color: viewMode===id ? "#f1f5f9" : "#64748b",
              borderBottom: viewMode===id ? "2px solid #3b82f6" : "2px solid transparent" }}>
            {label}
          </button>
        ))}
      </div>

      {/* ── MAIN CONTENT ── */}
      <div style={{ flex:1, overflowY:"auto", padding:"20px 24px 180px" }}>

        {/* TIMELINE VIEW */}
        {viewMode === "timeline" && (
          <div>
            {/* Mini chart */}
            <div style={{ background:"#111827", border:"1px solid #1e2d45", borderRadius:12, padding:"16px", marginBottom:20 }}>
              <div style={{ fontSize:12, color:"#64748b", marginBottom:8 }}>Chase Checking Balance — Next 6 Months</div>
              <MiniChart data={forecast} width={900} height={100}/>
              <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, color:"#475569", marginTop:4 }}>
                <span>{fmtD(forecast[0]?.date)}</span>
                <span>{fmtD(forecast[Math.floor(forecast.length/2)]?.date)}</span>
                <span>{fmtD(forecast[forecast.length-1]?.date)}</span>
              </div>
            </div>

            {/* Day-by-day rows — only show days with events */}
            <div style={{ display:"flex", flexDirection:"column", gap:2 }}>
              {forecast.filter(d => d.events.length > 0).map((day, i) => (
                <div key={i} className="day-row"
                  onClick={() => setSelectedDay(selectedDay && isSameDay(selectedDay.date, day.date) ? null : day)}
                  style={{ background:"#111827", border:"1px solid #1e2d45", borderRadius:8, padding:"10px 16px", cursor:"pointer",
                    borderLeft:`3px solid ${day.chaseBalance < 10000 ? "#ef4444" : day.chaseBalance < 25000 ? "#f59e0b" : "#1e3a5f"}` }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <div style={{ display:"flex", gap:12, alignItems:"center" }}>
                      <div style={{ minWidth:80, fontSize:12, color:"#64748b", fontFamily:"'DM Mono',monospace" }}>{fmtD(day.date)}</div>
                      <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                        {day.events.slice(0,4).map((e,j) => (
                          <span key={j} style={{ fontSize:11, padding:"2px 8px", borderRadius:4,
                            background: e.dir==="in" ? "#064e3b44" : e.dir==="out" ? "#7f1d1d33" : e.dir==="amex" ? "#78350f33" : e.dir==="visa" ? "#4c1d9544" : "#1e3a5f44",
                            color: e.dir==="in" ? "#6ee7b7" : e.dir==="out" ? "#fca5a5" : e.dir==="amex" ? "#fcd34d" : e.dir==="visa" ? "#c4b5fd" : "#93c5fd" }}>
                            {e.type==="cc_close"?"🔒 ":e.type==="cc_pay"?"💳 ":e.dir==="in"?"↑ ":"↓ "}{e.name||e.label}
                            {e.amount ? ` ${fmt(e.dir==="in"?e.amount:-e.amount)}` : ""}
                          </span>
                        ))}
                        {day.events.length > 4 && <span style={{fontSize:11,color:"#64748b"}}>+{day.events.length-4} more</span>}
                      </div>
                    </div>
                    <div style={{ fontSize:15, fontWeight:700, fontFamily:"'DM Mono',monospace", color: balColor(day.chaseBalance) }}>
                      {fmt(day.chaseBalance)}
                    </div>
                  </div>
                  {/* Expanded detail */}
                  {selectedDay && isSameDay(selectedDay.date, day.date) && (
                    <div style={{ marginTop:10, paddingTop:10, borderTop:"1px solid #1e2d45" }}>
                      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:8 }}>
                        <div style={{ fontSize:11, color:"#64748b" }}>
                          Amex accruing: <span style={{color:"#fcd34d",fontWeight:600}}>{fmt(day.amexAccruing)}</span>
                          <br/>Amex unpaid stmt: <span style={{color:"#fca5a5"}}>{fmt(day.amexStatement)}</span>
                        </div>
                        <div style={{ fontSize:11, color:"#64748b" }}>
                          Visa accruing: <span style={{color:"#c4b5fd",fontWeight:600}}>{fmt(day.visaAccruing)}</span>
                          <br/>Visa unpaid stmt: <span style={{color:"#fca5a5"}}>{fmt(day.visaStatement)}</span>
                        </div>
                      </div>
                      {day.events.map((e,j) => (
                        <div key={j} style={{ fontSize:12, padding:"4px 0", borderBottom:"1px solid #1e2d4530", display:"flex", justifyContent:"space-between" }}>
                          <span style={{ color: e.dir==="in"?"#6ee7b7":e.dir==="out"?"#fca5a5":"#94a3b8" }}>
                            {e.type==="cc_close"?"🔒":e.type==="cc_pay"?"💳":e.dir==="in"?"⬆":"⬇"} {e.name||e.label}
                            {e.notes && <span style={{color:"#64748b",marginLeft:6}}>({e.notes})</span>}
                          </span>
                          {e.amount && <span style={{fontFamily:"'DM Mono',monospace",fontWeight:600}}>{fmt(e.dir==="in"?e.amount:-e.amount)}</span>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MONTHLY VIEW */}
        {viewMode === "monthly" && (
          <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
            {monthlyGroups.map((mg, mi) => {
              const totalIn  = mg.days.flatMap(d=>d.events).filter(e=>e.type==="income").reduce((s,e)=>s+e.amount,0);
              const totalOut = mg.days.flatMap(d=>d.events).filter(e=>e.type==="expense"||e.type==="cc_pay").reduce((s,e)=>s+e.amount,0);
              const amexClose = mg.days.find(d=>d.events.some(e=>e.type==="cc_close"&&e.account==="amex"));
              const visaClose = mg.days.find(d=>d.events.some(e=>e.type==="cc_close"&&e.account==="visa"));
              return (
                <div key={mi} style={{ background:"#111827", border:"1px solid #1e2d45", borderRadius:12, overflow:"hidden" }}>
                  <div style={{ padding:"14px 20px", borderBottom:"1px solid #1e2d45", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <div style={{ fontWeight:700, fontSize:16 }}>{mg.label}</div>
                    <div style={{ display:"flex", gap:24 }}>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontSize:11,color:"#64748b"}}>Cash In</div>
                        <div style={{fontSize:15,fontWeight:700,color:"#10b981",fontFamily:"'DM Mono',monospace"}}>{fmt(totalIn)}</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontSize:11,color:"#64748b"}}>Cash Out</div>
                        <div style={{fontSize:15,fontWeight:700,color:"#ef4444",fontFamily:"'DM Mono',monospace"}}>{fmt(totalOut)}</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontSize:11,color:"#64748b"}}>End Balance</div>
                        <div style={{fontSize:15,fontWeight:700,color:balColor(mg.endBalance),fontFamily:"'DM Mono',monospace"}}>{fmt(mg.endBalance)}</div>
                      </div>
                    </div>
                  </div>
                  <div style={{ padding:"12px 20px", display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                    {amexClose && (
                      <div style={{ background:"#78350f22", border:"1px solid #78350f44", borderRadius:8, padding:"8px 12px" }}>
                        <div style={{fontSize:11,color:"#64748b"}}>Amex Statement Closes {fmtD(amexClose.date)}</div>
                        <div style={{fontSize:14,fontWeight:700,color:"#fcd34d",fontFamily:"'DM Mono',monospace"}}>
                          {fmt(amexClose.events.find(e=>e.type==="cc_close"&&e.account==="amex")?.amount||0)}
                        </div>
                        <div style={{fontSize:11,color:"#64748b"}}>Due 6th of following month</div>
                      </div>
                    )}
                    {visaClose && (
                      <div style={{ background:"#4c1d9522", border:"1px solid #4c1d9544", borderRadius:8, padding:"8px 12px" }}>
                        <div style={{fontSize:11,color:"#64748b"}}>Visa Statement Closes {fmtD(visaClose.date)}</div>
                        <div style={{fontSize:14,fontWeight:700,color:"#c4b5fd",fontFamily:"'DM Mono',monospace"}}>
                          {fmt(visaClose.events.find(e=>e.type==="cc_close"&&e.account==="visa")?.amount||0)}
                        </div>
                        <div style={{fontSize:11,color:"#64748b"}}>Due 18th of following month</div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* BILLS VIEW */}
        {viewMode === "bills" && (
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            <div style={{ fontSize:13, color:"#64748b", marginBottom:4 }}>
              {state.recurringBills.filter(b=>b.active).length} active recurring bills · {state.oneOffExpenses.length} one-off expenses
              <span style={{marginLeft:12,color:"#f59e0b"}}>Use the chatbot to add, edit, or remove any bill</span>
            </div>
            {Object.entries(
              state.recurringBills.reduce((acc,b) => {
                const cat = b.category||"other";
                if(!acc[cat]) acc[cat]=[];
                acc[cat].push(b);
                return acc;
              }, {})
            ).map(([cat,bills]) => (
              <div key={cat} style={{ background:"#111827", border:"1px solid #1e2d45", borderRadius:10, overflow:"hidden" }}>
                <div style={{ padding:"10px 16px", borderBottom:"1px solid #1e2d45", fontSize:12, fontWeight:600, textTransform:"uppercase", letterSpacing:"0.05em",
                  color: categoryColors[cat]||"#94a3b8", background:"#0d1420" }}>
                  {cat.replace("_"," ")}
                </div>
                {bills.map((b,i) => (
                  <div key={i} className="bill-row" style={{ padding:"8px 16px", borderBottom:"1px solid #1e2d4530", display:"flex", justifyContent:"space-between", alignItems:"center",
                    opacity: b.active ? 1 : 0.4 }}>
                    <div>
                      <div style={{ fontSize:13, fontWeight:500 }}>{b.name}
                        {b.notes && b.notes.includes("⚠️") && <span style={{marginLeft:6,fontSize:11,color:"#f59e0b"}}>⚠️ needs confirmation</span>}
                      </div>
                      <div style={{ fontSize:11, color:"#64748b" }}>
                        {b.frequency} · {b.account} · {b.dayOfMonth ? `due ${b.dayOfMonth}th` : b.dayOfWeek!==undefined ? ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][b.dayOfWeek]+"s" : ""}
                        {b.startDate && ` · starts ${fmtD(new Date(b.startDate))}`}
                        {b.endDate && ` · ends ${fmtD(new Date(b.endDate))}`}
                      </div>
                    </div>
                    <div style={{ fontFamily:"'DM Mono',monospace", fontWeight:700, fontSize:14, color: b.category==="income"?"#10b981":"#f1f5f9" }}>
                      {b.category==="income"?"+":"-"}{fmt(b.amount)}
                    </div>
                  </div>
                ))}
              </div>
            ))}
            {state.oneOffExpenses.length > 0 && (
              <div style={{ background:"#111827", border:"1px solid #1e2d45", borderRadius:10, overflow:"hidden" }}>
                <div style={{ padding:"10px 16px", borderBottom:"1px solid #1e2d45", fontSize:12, fontWeight:600, textTransform:"uppercase", color:"#f97316" }}>One-Off Expenses</div>
                {state.oneOffExpenses.map((e,i) => (
                  <div key={i} className="bill-row" style={{ padding:"8px 16px", borderBottom:"1px solid #1e2d4530", display:"flex", justifyContent:"space-between" }}>
                    <div>
                      <div style={{fontSize:13,fontWeight:500}}>{e.name}</div>
                      <div style={{fontSize:11,color:"#64748b"}}>{fmtFull(new Date(e.date))} · {e.account}</div>
                    </div>
                    <div style={{fontFamily:"'DM Mono',monospace",fontWeight:700}}>-{fmt(e.amount)}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {viewMode === "networth" && (() => {
          // ── NET WORTH PROJECTION ────────────────────────────────────────
          const NW_YEARS = [2026,2027,2028,2029,2030,2031,2032];

          // Starting balances
          const START_BROKERAGE   = 202873 + 73179;  // Bernstein Joint + Fidelity + Chase
          const START_RETIREMENT  = 1100952;
          const START_COLLEGE     = 113981;
          const START_JSTOCK      = 766046;  // Jennie vested Athletic stock
          const START_HOME_EQUITY = 746477;

          // Ben AB stock vest schedule (gross, Dec 1 each year)
          // Existing unvested $86,893 → 1/3 per year 2026-2028
          // New grants: 25% of gross bonus, vest 1/3 over 3 yrs
          const grossBonuses = {2026:275000,2027:300000,2028:350000,2029:400000,2030:450000,2031:500000,2032:500000};
          const abVestSchedule = {};
          for(let yr=2026;yr<=2028;yr++) abVestSchedule[yr] = (abVestSchedule[yr]||0) + 86893/3;
          Object.entries(grossBonuses).forEach(([gyr,bonus])=>{
            const grant = bonus*0.25;
            for(let i=1;i<=3;i++){
              const vy = parseInt(gyr)+i;
              abVestSchedule[vy] = (abVestSchedule[vy]||0) + grant/3;
            }
          });
          const TAX_VEST = 0.37+0.0934+0.0235; // 48.69%

          // Annual cash savings to brokerage (net income after expenses, grows 3%/yr)
          // Daycare savings: Evie stops Jun 2027 (+$21,600/yr), Hugh stops Jun 2030 (+$21,600/yr)
          const baseSavings = 115000;
          const DAYCARE_PER_CHILD = 21600; // $450/wk × ~48 weeks

          // Build year-by-year projections
          let brokerage   = START_BROKERAGE;
          let retirement  = START_RETIREMENT;
          let college     = START_COLLEGE;
          let jStock      = START_JSTOCK;
          let homeEquity  = START_HOME_EQUITY;

          const rows = NW_YEARS.map(year => {
            brokerage  = brokerage  * 1.07;
            retirement = retirement * 1.07;
            college    = college    * 1.07;
            jStock     = jStock     * 1.07;
            homeEquity = homeEquity * 1.02;

            // Contributions — base savings plus daycare savings as each child ages out
            const daycareSavings = (year >= 2027 ? DAYCARE_PER_CHILD : 0) +  // Evie stops Jun 2027
                                   (year >= 2030 ? DAYCARE_PER_CHILD : 0);    // Hugh stops Jun 2030
            brokerage  += baseSavings * Math.pow(1.03, year-2026) + daycareSavings;

            // Jennie bonus sweep (arrives Feb 13 each year)
            // Ben's bonus ($104,480) lands Dec 20, so Chase is ~$144k before Jennie's bonus
            // After Jennie's bonus (~$24-29k), Chase is ~$168k
            // Keep $40k floor ($72k in 2026 to cover April tax true-up), sweep the rest
            const jennieBonusNet = Math.round(24633 * Math.pow(1.03, year - 2026));
            const benBonusNet = year === 2026 ? 104480 : Math.round(104480 * Math.pow(1.03, year - 2026));
            // Chase before Jennie bonus: ~$40k base + Ben bonus - Jan/Dec bills (~$2k net drain)
            const chaseBeforeJennie = 40000 + benBonusNet - 2000;
            const chaseAfterJennie = chaseBeforeJennie + jennieBonusNet;
            const chaseTarget = year === 2026 ? 72000 : 40000; // 2026: cover April tax
            const sweepAmount = Math.max(0, chaseAfterJennie - chaseTarget);
            brokerage += sweepAmount;
            retirement += 23500 + 15000 + 23500 + 9750; // Ben + Jennie 401k+match
            college    += 10000;

            // AB stock vesting → brokerage (after-tax)
            const vestGross = abVestSchedule[year] || 0;
            brokerage += vestGross * (1 - TAX_VEST);

            const total = brokerage + retirement + college + jStock + homeEquity;
            return { year, brokerage, retirement, college, jStock, homeEquity, total,
                     benBonus: grossBonuses[year]||500000,
                     abVest: vestGross };
          });

          const maxTotal = Math.max(...rows.map(r=>r.total));
          const fmt2 = n => n >= 1e6 ? `$${(n/1e6).toFixed(2)}M` : `$${Math.round(n/1000)}k`;
          const barW = (val) => `${Math.round((val/maxTotal)*100)}%`;

          const cats = [
            { key:"brokerage",  label:"Brokerage / Cash", color:"#10b981" },
            { key:"retirement", label:"Retirement",        color:"#6366f1" },
            { key:"college",    label:"College (529)",     color:"#8b5cf6" },
            { key:"jStock",     label:"Jennie Stock",      color:"#f59e0b" },
            { key:"homeEquity", label:"Home Equity",       color:"#0891b2" },
          ];

          return (
            <div style={{flex:1,overflowY:"auto",padding:"24px",background:"#0a0e1a"}}>
              <div style={{maxWidth:900,margin:"0 auto"}}>
                <div style={{marginBottom:24}}>
                  <div style={{fontSize:20,fontWeight:700,marginBottom:4}}>Net Worth Projection</div>
                  <div style={{fontSize:12,color:"#64748b"}}>7% equity growth · Ben comp ramps to $800k · Jennie 3% salary inflation · AB stock vests 1/3/yr Dec 1 · Jennie bonus swept to brokerage · Evie daycare ends Jun 2027 · Hugh daycare ends Jun 2030</div>
                </div>

                {/* Summary cards */}
                <div style={{display:"flex",gap:12,marginBottom:28,flexWrap:"wrap"}}>
                  {rows.filter(r=>[2026,2028,2030,2032].includes(r.year)).map(r=>(
                    <div key={r.year} style={{flex:1,minWidth:160,background:"#111827",border:"1px solid #1e2d45",borderRadius:12,padding:"16px 20px"}}>
                      <div style={{fontSize:12,color:"#64748b",marginBottom:4}}>{r.year} Year-End</div>
                      <div style={{fontSize:22,fontWeight:700,color:"#10b981",fontFamily:"'DM Mono',monospace"}}>{fmt2(r.total)}</div>
                      <div style={{fontSize:11,color:"#64748b",marginTop:6}}>
                        Ben comp: ${(300000+r.benBonus).toLocaleString()}<br/>
                        AB vest: {fmt2(r.abVest)} gross
                      </div>
                    </div>
                  ))}
                </div>

                {/* Stacked bar chart */}
                <div style={{background:"#111827",border:"1px solid #1e2d45",borderRadius:12,padding:20,marginBottom:20}}>
                  <div style={{fontSize:13,fontWeight:600,marginBottom:16,color:"#94a3b8"}}>Net Worth Composition by Year</div>

                  {/* Legend */}
                  <div style={{display:"flex",gap:16,marginBottom:16,flexWrap:"wrap"}}>
                    {cats.map(c=>(
                      <div key={c.key} style={{display:"flex",alignItems:"center",gap:6,fontSize:12}}>
                        <div style={{width:10,height:10,borderRadius:2,background:c.color}}/>
                        <span style={{color:"#94a3b8"}}>{c.label}</span>
                      </div>
                    ))}
                  </div>

                  {rows.map(r => (
                    <div key={r.year} style={{marginBottom:12}}>
                      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:4}}>
                        <div style={{width:40,fontSize:12,color:"#64748b",fontWeight:600}}>{r.year}</div>
                        <div style={{flex:1,height:28,borderRadius:4,overflow:"hidden",display:"flex"}}>
                          {cats.map(c=>(
                            <div key={c.key} style={{width:`${Math.round((r[c.key]/r.total)*100)}%`,background:c.color,height:"100%",transition:"width 0.3s"}}
                              title={`${c.label}: ${fmt2(r[c.key])}`}/>
                          ))}
                        </div>
                        <div style={{width:80,textAlign:"right",fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:700,color:"#10b981"}}>{fmt2(r.total)}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Detail table */}
                <div style={{background:"#111827",border:"1px solid #1e2d45",borderRadius:12,overflowX:"auto"}}>
                  <table style={{width:"100%",borderCollapse:"collapse",fontSize:11,minWidth:700}}>
                    <thead>
                      <tr style={{background:"#161d2e"}}>
                        <th style={{padding:"10px 16px",textAlign:"left",color:"#64748b",fontWeight:600}}>Year</th>
                        {cats.map(c=><th key={c.key} style={{padding:"8px 8px",textAlign:"right",color:c.color,fontWeight:600,whiteSpace:"nowrap"}}>{c.label}</th>)}
                        <th style={{padding:"8px 8px",textAlign:"right",color:"#22c55e",fontWeight:700,borderLeft:"1px solid #2d3f60",whiteSpace:"nowrap"}}>Liquid Total</th>
                        <th style={{padding:"10px 16px",textAlign:"right",color:"#f1f5f9",fontWeight:700}}>Total</th>

                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((r,i)=>(
                        <tr key={r.year} style={{borderTop:"1px solid #1e2d4544",background:i%2===0?"transparent":"#0d1424"}}>
                          <td style={{padding:"10px 16px",fontWeight:700}}>{r.year}</td>
                          {cats.map(c=><td key={c.key} style={{padding:"8px 8px",textAlign:"right",fontFamily:"'DM Mono',monospace",color:"#e2e8f0"}}>{fmt2(r[c.key])}</td>)}
                          <td style={{padding:"8px 8px",textAlign:"right",fontFamily:"'DM Mono',monospace",fontWeight:700,color:"#22c55e",borderLeft:"1px solid #2d3f60"}}>{fmt2(r.brokerage+r.retirement+r.college)}</td>
                          <td style={{padding:"10px 16px",textAlign:"right",fontFamily:"'DM Mono',monospace",fontWeight:700,color:"#10b981"}}>{fmt2(r.total)}</td>

                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div style={{marginTop:16,fontSize:11,color:"#475569",lineHeight:1.6}}>
                  * Brokerage/Cash includes Chase checking, Bernstein Joint, Fidelity, annual cash savings (incl. daycare savings: Evie stops Jun 2027, Hugh stops Jun 2030), and AB stock vesting proceeds after ~49% withholding.
                  Retirement includes all 401k, IRA, and employer match contributions compounding at 7%.
                  Jennie's Athletic stock grown at 7% from current $766k vested value (option intrinsic value depends on Athletic Brewing valuation).
                  Home equity grows at 2%/yr. All figures are estimates.
                </div>
              </div>
            </div>
          );
        })()}

      </div>

      {/* ── CHAT PANEL ── */}
      <div style={{ position:"fixed", bottom:0, left:0, right:0, background:"#111827", borderTop:"1px solid #1e2d45", zIndex:100 }}>
        {/* Chat history */}
        <div style={{ maxHeight:200, overflowY:"auto", padding:"12px 24px 0" }}>
          {state.chatHistory.length === 0 && (
            <div style={{ fontSize:12, color:"#475569", fontStyle:"italic", paddingBottom:8 }}>
              Ask me to update any bill, balance, or add an expense. e.g. "Change Magical Beginnings tuition to $450/week starting March 1" or "Add a $3,000 home repair expense on April 20, charged to Amex"
            </div>
          )}
          {state.chatHistory.map((m,i) => (
            <div key={i} style={{ marginBottom:8, display:"flex", gap:8, alignItems:"flex-start" }}>
              <div style={{ fontSize:11, color:m.role==="user"?"#3b82f6":"#10b981", fontWeight:700, minWidth:40, paddingTop:1 }}>
                {m.role==="user"?"You":"AI"}
              </div>
              <div style={{ fontSize:13, color:"#cbd5e1", lineHeight:1.5 }}>{m.content}</div>
            </div>
          ))}
          {isThinking && (
            <div style={{ fontSize:12, color:"#64748b", fontStyle:"italic", marginBottom:8 }}>AI is thinking...</div>
          )}
          {/* Pending change confirmation */}
          {state.pendingChange && (
            <div style={{ background:"#1e3a5f33", border:"1px solid #3b82f660", borderRadius:8, padding:"10px 14px", marginBottom:8, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <div style={{ fontSize:12, color:"#93c5fd" }}>Apply this change to the forecast?</div>
              <div style={{ display:"flex", gap:8 }}>
                <button className="confirm-btn" onClick={applyChange}
                  style={{ padding:"5px 16px", background:"#10b981", border:"none", borderRadius:6, color:"white", fontSize:12, fontWeight:700, cursor:"pointer" }}>
                  ✓ Confirm
                </button>
                <button className="confirm-btn" onClick={rejectChange}
                  style={{ padding:"5px 16px", background:"#374151", border:"none", borderRadius:6, color:"#94a3b8", fontSize:12, cursor:"pointer" }}>
                  ✗ Cancel
                </button>
              </div>
            </div>
          )}
          <div ref={chatEndRef}/>
        </div>

        {/* Input */}
        <div style={{ padding:"10px 24px 14px", display:"flex", gap:10 }}>
          <input
            ref={chatInputRef}
            className="chat-input"
            value={chatInput}
            onChange={e=>setChatInput(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&!e.shiftKey&&sendMessage()}
            placeholder="Update a bill, add an expense, change a date or amount..."
            style={{ flex:1, background:"#161d2e", border:"1px solid #1e2d45", borderRadius:8, padding:"10px 14px", color:"#f1f5f9", fontSize:13, fontFamily:"inherit" }}
          />
          <button className="send-btn" onClick={sendMessage} disabled={isThinking}
            style={{ padding:"10px 20px", background:"#3b82f6", border:"none", borderRadius:8, color:"white", fontSize:13, fontWeight:700, cursor:"pointer", opacity:isThinking?0.6:1 }}>
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
